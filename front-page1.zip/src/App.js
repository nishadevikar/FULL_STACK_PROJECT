import logo from './logo.svg';
import './App.css';
import Navigation from './view/Navigation.js';
import FooterPage from './view/FooterPage';
import TopContent from './view/TopContent';
import MiddleContent from './view/MiddleContent';
import Content from './view/Content';
import TextBox from './view/TextBox';

function App() {
  return (
    <div>
      <header>
        <Navigation/>
       
        <TopContent/>
      
        <MiddleContent/>
        
      </header>
      <FooterPage/>
    </div>
  );
}

export default App;
