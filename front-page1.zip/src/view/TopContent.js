import React from 'react';
import {UncontrolledCarousel} from 'reactstrap';

class TopContent extends React.Component{
    render()
    {
        return(
            <div className='carouseldiv'>
               
                <UncontrolledCarousel
  items={[
    

    {
      altText: '',
      caption: '',
      key: 1,
      src: 'img2.jpg'
    },
    {
      altText: '',
      caption: '',
      key: 2,
      src: 'img3.jpg'
    }
  ]}
 />
            </div>

        );
    }
}
export default TopContent;