import React from 'react';

class MiddleContent extends React.Component{
    render()
    {
        return(
           <div className='midcontent'>
               <center>
               <h2>Suitable Online Assessment Platform for Smooth Exams</h2>
               <h6>Utmost solution for catering industry needs for online examination</h6><br></br><br></br>

               <h2>A Revolutionary Step in the Online Examination System</h2>
               <h6>It is an exceptional platform for conducting online exams and
solving all your preparation doubts. It is a smooth platform to use and enhances the flow of information.
</h6>
               </center>
           </div>
        );
    }
}
export default MiddleContent;