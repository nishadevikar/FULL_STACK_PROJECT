import React from 'react';

class ContactUs extends React.Component{
    render()
    {
        return(
            <div className='contactdiv'>
                <p></p>
            </div>
        );
    }
}
export default ContactUs;