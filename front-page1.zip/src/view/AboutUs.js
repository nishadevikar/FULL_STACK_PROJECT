import React from 'react';

class AboutUs extends React.Component{
    render()
    {
        return(
           <div className='avoutdiv'>
               <h4>About Us</h4>
               <p>Online Examination System is a technology-driven way to simplify examination activities like defining exam patterns with question banks, defining exam timer, objective/ subjective question sections, conducting exams using the computer or mobile devices in a paperless manner.

Online Examination System is a cost-effective, scalable way to convert traditional pen and paper-based exams to online and paperless mode.</p>
           </div>
        );
    }
}
export default AboutUs;