import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import {NavItem,NavLink,Nav} from 'reactstrap'
class Navigation extends React.Component{
    render()
    {
        return(
          <div className='navbar navbar-expand-lg fixed-top'>
          <Nav className="ml-auto">
          
            <NavItem>
              <NavLink
                active
                href="#"
              >
                Home
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink href="#">
                About Us
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                href="#"
              >
                Contact Us
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                href="#"
              >
                Login
              </NavLink>
            </NavItem>
          </Nav>
        </div>
        );
    }
}
export default Navigation;