import React from "react";
import AboutUs from "./AboutUs";
class FooterPage extends React.Component{
    render()
    {
  return (
      <>
     <div className="footerdiv">
         <footer>
             <center>
             <h4><b>Online Test</b></h4>
             <hr>
             </hr>
             
         
           <p>Home</p><br></br>
           <a href='./AboutUs'>About Us</a><br></br>
           <p>Contact Details</p>
           <hr className="vl">
           </hr>
           <p>&copy;2022 OnlineTest</p>
          </center> 
       </footer>
       
       </div>
       
       </>
   );
 }
}

export default FooterPage;