import React from 'react';

class Content extends React.Component{
    render()
    {
        return(
            <div>
                <center>
                <h2><b>Insights About our Success Story</b></h2>
                <p>We offer splendid services to our customers and have conducted numerous assessments and exams in a session at a time.</p>

                </center>
                
            </div>
        );
    }
}
export default Content;