import React from 'react';
 
class TextBox extends React.Component{
    render()
    {
        return(
            <div>
                <div className='extradiv'>

                </div>
           <div className='textdiv'>
               <h4><b>Learning Outside The Classroom</b></h4>
               <p>with emphasis on learning through technology Centralized Integrated, Multilinguial, User-friendly and Efficient learning Platform</p>
           </div>
           </div>
        );
    }
}
export default TextBox;