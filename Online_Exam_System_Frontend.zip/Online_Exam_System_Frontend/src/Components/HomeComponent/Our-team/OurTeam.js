import React from "react";
import SrmImg from "../../../assests/images/PrakashManapilly.jpg";
import Img from "../../../assests/images/SnehalPawar.jpg";
import aboutImg from "../../../assests/images/JaynamSanghvi.jpg";
import './team.css';

export default function Kit() {
    console.log(Kit);
    return (
        <section id="team" class="team">

        <h1 class="heading">OUR MENTOR</h1>
        
        <div class="row">
        
       
    
        <div class="card">
          <div class="image">
          <img src={SrmImg} alt="img" height="315"/>
          </div>
          <div class="info">
            <h3>Prakash Manapilly</h3>
            <span>SRM</span>
           
          </div>
        </div>
        
        <div class="card">
          <div class="image">
          <img src={Img} alt="img" height="315"/>
          </div>
          <div class="info">
            <h3>Snehal Pawar</h3>
            <span>IRM</span>
           
          </div>
        </div>
        
        <div class="card">
          <div class="image">
          <img src={aboutImg} alt="img" height="315"/>
          </div>
          <div class="info">
            <h3>Jaynam Sanghvi</h3>
            <span>Technical Trainer</span>
           
          </div>
        </div>
        
        </div>
    
        </section>
    );
}