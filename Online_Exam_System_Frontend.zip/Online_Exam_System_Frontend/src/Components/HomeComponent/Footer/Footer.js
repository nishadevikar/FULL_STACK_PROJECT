import React from 'react'
import './Footer.css';
 function Footer() {
  return (
        <div>
           
            <p>TEAM-1</p>
            <p><a href="mailto:yash.com">@2022 Copyright : yash.com</a></p>
        </div>
  )
}

export default Footer;