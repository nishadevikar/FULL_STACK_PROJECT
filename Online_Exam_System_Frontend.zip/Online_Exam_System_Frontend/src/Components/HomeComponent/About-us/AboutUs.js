import React from "react";
import aboutImg from "../../../assests/images/about-us.png";
import './about.css';
import { Container, Row, Col } from "reactstrap";

export default function Kit() {
  console.log(Kit);
  return (
    <section>
    <Container>
      <Row>
    <Col lg="6" md="6">
    <div className="about" style={{display: "flex"}}>
    
      
    <img src={aboutImg} alt="img" height="315"/>
      <p className="mb-5">
      
        <h2 className="mb-4 hero__title">About Us</h2>
        A great and helpful tool for all the youngsters to give <br/>and test the performance of 
                oneself. <br />
                The online exam system manages the administrator as <br />
                well as the students and deliver 
                the best performance <br />one can expect.
      </p>
      
    </div>
    </Col>
    </Row>
    </Container>
    </section>
  );
}