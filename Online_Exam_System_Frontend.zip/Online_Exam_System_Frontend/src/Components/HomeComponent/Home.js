import Header from "./Header";
import Introduction from "./Introduction/Introduction";
import AboutUs from "./About-us/AboutUs";
import Features from "./Feature-us/Feature";
import Footer from "./Footer/Footer";
import OurTeam from "./Our-team/OurTeam";




function Home(){

    return (
        <>
        <div>
        <Header />
        <br />
        <br />
        <br />
        <br />
       
        <Introduction />
        <br />
        <br />
        <br />
        <br />
        <br />
        <AboutUs />
        <br />
        <br />
        <br />
        <br />
        <br />
        <OurTeam />
        <br />
        <Features />
        <br />
        <hr />
        <Footer />

        
          
          </div>
        </>
      )
    }



     



    export default Home;