import React from "react";
import testImg from "../../../assests/images/testimonial01.png";
import './Feature.css';
import { Container, Row, Col } from "reactstrap";

export default function Kit() {
  console.log(Kit);
  return (
    <section>
    <Container>
      <Row>
    <Col lg="6" md="6">
     <div className="intro__content" style={{display: "flex"}}>
     
      <br />
      <p className="mb-5">
        <h2 className="mb-4 hero__title">Why Online Exam?</h2>
        The benefits of online assessment are welcomed by both the exam candidates themselves,
         and for the organization providing the assessment. <br />It also provides benefits to student learning. 
         The types of benefits gained from an online assessment will depend on the assessment software used, but one overriding positive outcome is that organizations greatly reduce the administrative burden of organizing and running exams. 
      </p>
      <img src={testImg} alt="img" height="315"/>
    </div>
    </Col>
    </Row>
    </Container>
    </section>
  );
}