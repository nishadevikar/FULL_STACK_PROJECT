import React from "react";
import heroImg from "../../../assests/images/hero-img1.jpg";
import './intro.css';
import { Container, Row, Col } from "reactstrap";

export default function Kit() {
  console.log(Kit);
  return (
    <section>
    <Container>
      <Row>
    <Col lg="6" md="6">
     <div className="intro__content" style={{display: "flex"}}>
     
      <br />
      <p className="mb-5">
        <h2 className="mb-4 hero__title">Anytime Anywhere <br /> Learn on your <br /> Suitable Schedule </h2>
        Manage online examinations: <br />
        From candidate registration and online <br /> proctoring to 
        quick results and real-time processing.
      </p>
      <img src={heroImg} alt="img" height="315"/>
    </div>
    </Col>
    </Row>
    </Container>
    </section>
  );
}