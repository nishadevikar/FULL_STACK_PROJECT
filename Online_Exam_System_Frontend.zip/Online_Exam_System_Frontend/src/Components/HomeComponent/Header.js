import React from 'react'
import {Link} from "react-router-dom";
import style from './Home.module.css';

export default function Header() {
  return (
    <div id={style.header} style={{justifyContent:'space-between'}}>
    <div id={style.headerHeadingBox}>
         <h3>Online Exam System</h3> 
     </div>
     <div className={style} style={{marginTop:'12px'}}>
    
     <Link className={style.navOption} style={{textDecoration:'none'}} exact to="/AdminLogin"><button style={{border:'none',backgroundColor:'white',color:'blue'}} >Admin</button></Link>
    <Link className={style.navOption} style={{textDecoration:'none'}} exact to="/StudentLogin"><button  style={{border:'none',backgroundColor:'white',color:'blue'}}>Student</button></Link>
    </div>
    </div>       
  )
}
