

 import { NavLink , useHistory } from "react-router-dom";

 import axios from "axios";
 import { useState } from "react";


  import style from "./StudentSignup.module.css";

  import baseUrl from "../../baseUrl";



function StudentSignup() {


    // const [name, setName]= useState("");

    // const [nameError, setNameError] = useState("");


     const [userData , setUserData] = useState({
        name: "",
        email: "",
        password: ""
     });

     function onTextFieldChange(e){
         setUserData({
             ...userData,
             [e.target.name] : e.target.value
         });
     }


      const [password , setPassword] = useState("");

      function handlePassword(e){
        setPassword(e.target.value);

      

    }
    

    let history = useHistory();
    
   async function handleSignup(){
        // console.log(userData);
        // console.log(password);
        if(password===""){
            alert("fields cant be empty")
        }
        else{
        if(userData.password === password)
        {
            await axios.post(`${baseUrl}/user` , userData);
            alert("Your account has created");
            alert("Please Login");
            history.push("/StudentLogin");
        }
        else alert("password did not match");

        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
        if(userData.email === regex.email)
        {
            await axios.post(`${baseUrl}/user` , userData);
            alert("Your account has created");
            alert("Please Login");
            history.push("/StudentLogin");

        }
        else alert("Welcome To Test");
    }
        
    }

    



    return (
        <div id={style.container}>

            <div id={style.formHeading}>
                <h1>Student Signup</h1>
                <p>Please complete the form below to register with us</p>
            </div>

            <div id={style.nameBox}>
                <label htmlFor="name" style={{marginLeft:'170px'}}>Name 
                    <input onChange={(e) => onTextFieldChange(e)} 
                    type="text" name="name" placeholder="Name"  required />
                </label>
            </div>


            <div id={style.emailBox}>
                <label htmlFor="email" style={{marginLeft:'170px'}}> Email
                    <input onChange={(e) => onTextFieldChange(e)}  
                    type="text" name="email" placeholder="Email" required />
                </label>
            </div>

            <div id={style.passwordBox}>
                <label htmlFor="password" style={{marginLeft:'170px'}}> Password
                    <input onChange={(e) => onTextFieldChange(e)} 
                    type="password" name="password" placeholder="Password" required />
                </label>
            </div>


            <div id={style.confirmPasswordBox}>
                <label htmlFor="confirmPassword" style={{marginLeft:'170px'}}>Confirm Password
                    <input  onChange={(e) => handlePassword(e)}
                     type="password" name="confirmPassword" placeholder="Confirm Password" required />
                </label>
            </div>


            {/* <button id={style.signup} onclick="signup()">Sign Up</button> */}
            <button id={style.signup} onClick={handleSignup} >Sign Up</button>


            <div id={style.login}>
                Have a Account?  <NavLink exact to="/StudentLogin"> Log in</NavLink>
            </div>


        </div>
    );
    }

export default StudentSignup;