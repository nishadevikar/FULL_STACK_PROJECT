

import axios from "axios";
import React, { useState, useEffect } from "react";
import { useParams, NavLink } from "react-router-dom";

import style from "../StudentDashboard.module.css";

import baseUrl from "../../../baseUrl";
import { useHistory } from "react-router-dom";
import { Alert } from "bootstrap";

const Gotoexam = ({ id, startdate, enddate }) => {
    //console.log(id)

    const history = useHistory();
    let { category } = useParams();

    const cameraOn = async () => {
        let ts = new Date(startdate);//14
        let t1 = new Date();//13
        let te = new Date(enddate);//15

        if (ts > t1) { alert("Test is not started Yet"); }
        else if (te < t1) { alert("Test is expire"); }
        else {

            var flag = 0;
            let value = await axios.get(`${baseUrl}/user/${sessionStorage.getItem("user")}/result`);
            value.data.map(data => {
                if (data.examId.id === id) {
                    flag = 1
                }
            })
            if (flag) {
                alert("test already attempted")
            }
            else {
                navigator.mediaDevices.getUserMedia({
                    video: true,
                    audio: false
                }).then((stream) => {
                    alert("Start exam")
                    const tracks = stream.getTracks();
                    tracks.forEach(function (track) {
                        track.stop();
                    });
                    history.push(`/StudentDashboard/Exam/${category}/${id}`)
                }).catch(() => {
                    alert("Please allow camera")
                })

            }
        }
    }

    return (
        <div>
            <button onClick={cameraOn}>Go to Exam</button>
        </div>
    )
}




function Exam() {

    const history = useHistory();
    let { category } = useParams();
    const [allExam, setAllExam] = useState([]);

    useEffect(() => {
        async function getAllExams() {
            let value = await axios.get(`${baseUrl}/exam`);
            setAllExam(value.data);
            // console.log(value.data);
        }
        getAllExams();
    }, [])







    return (
        <>
            <div id={style.displayBoxHeadingBox}>
                <h1>All {category} Exam</h1>
            </div>
            {
                allExam.map((data, i) => {
                    if (data.name.name === category)
                        return (
                            <div id={style.displayBoxExamBox} key={i}>
                                <div id={style.div1}> <span>{data.name.name}</span> </div>
                                <div id={style.div2}> <span>Exam ID: {data.id}</span> </div>
                                <div id={style.div2}> <span>Exam Description: {data.desc}</span> </div>
                                <div id={style.div3}><span>Pass Marks:{data.passMarks}</span> </div>
                                <div id={style.div4}><span>Total Marks:{data.marks}</span></div>
                                <div id={style.div4}><span>Total Questions:{data.totalQuestion}</span></div>
                                <div id={style.div4}><span>start Exam date time:{data.startdate}</span></div>
                                <div id={style.div4}><span>End Exam date time:{data.enddate}</span></div>
                                <div id={style.div5}>
                                    {/* <NavLink exact to={`/StudentDashboard/Exam/${category}/${data.id}`}> */}

                                    {/* </NavLink> */}
                                    <Gotoexam id={data.id} enddate={data.enddate} startdate={data.startdate} />
                                </div>
                            </div>
                        );

                    return <React.Fragment key={i}></React.Fragment>

                })
            }
        </>
    );
}
export default Exam;