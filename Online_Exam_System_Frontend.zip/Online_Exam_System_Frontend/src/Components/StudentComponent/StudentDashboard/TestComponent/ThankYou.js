import React from 'react'

function ThankYou() {
  return (
    <div>
      THANK YOU FOR ATTEMPTING THE TEST
    </div>
  )
}

export default ThankYou;
