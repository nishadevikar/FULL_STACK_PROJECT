
  
  
   import style from "./Dashboard.module.css";

   import {useState  , useEffect} from "react";
   import { useHistory } from "react-router-dom";
   import axios from "axios";
   import image from "./image/back.png";

   import baseUrl from "../../../baseUrl";

     function Dashboard()
     {

          const [exam , setExam] = useState("Updating...");
          const [question , setQuestion] = useState("Updating...");
          const [user , setUser] = useState("Updating...");

            useEffect(() => {
                async function getAllExam(){
                    let value  = await axios.get(`${baseUrl}/exam`);
                    setExam("We have total " +value.data.length + " exam");
                }
                getAllExam();


                async function getAllQuestions(){
                    let value  = await axios.get(`${baseUrl}/question`);
                    setQuestion("We have total " +value.data.length + " question");
                }
                getAllQuestions();


                async function getAllUsers(){
                    let value  = await axios.get(`${baseUrl}/user`);
                    setUser("We have total " +value.data.length + " user");
                }
                getAllUsers();
            })

 
             let history = useHistory();

            function showExam(){
                 history.push("/AdminDashboard/Exam");
            }

            function showQuestions(){
                history.push("/AdminDashboard/Question");
            }

            function showUsers(){
                history.push("/AdminDashboard/StudentList");
            }


         return(
             <div>
                           <div id={style.displayHeadingBox}> 
                               
                           </div>

                            <div>
                               {/*<p id={style.countOfExam}>{exam}</p>*/}
                               <div id={style.container}>
                                  <div id={style.leftdiv}>
                                  <br></br><br></br>
                                    <p id={style.countOfExam}>{exam}</p><br></br>
                                    <button id={style.btn} role="button" onClick={showExam}>View Details</button>
                                  </div>
                                  <div id={style.centerdiv}>
                                  <br></br><br></br>
                                    <p id={style.countOfQuestions}>{question}</p><br></br>
                                    <button id={style.btn} role="button" onClick={showQuestions}>View Details</button>
                                  </div>
                                  <div id={style.rightdiv}>
                                  <br></br><br></br>
                                    <p id={style.countOfUser}>{user}</p><br></br>
                                    <button id={style.btn} role="button" onClick={showUsers}>View Details</button>
                                  </div>
                               </div>
                                   {/*<button onClick={showExam}>View Details</button>*/}
                            </div>

                              {/*<div id={style.box2}>
                                  <p  id={style.countOfQuestion}>{question}</p>
                                   <button onClick={showQuestions}>View Details</button> 
                              </div>

                              <div id={style.box3}>
                                  <p id={style.countOfUser}>{user}</p>
                                    <button onClick={showUsers} >View Details</button>
                              </div>*/}
         </div>
                             
            
         );
     }

     export default Dashboard;