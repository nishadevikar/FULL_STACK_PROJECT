import "./Sidebar.css";
import logo from "../../assets/logo.png";
const Sidebar = ({sidebarOpen, closeSidebar }) => {
    return (
        <div className = {sidebarOpen ? "sidebar-responsive" : ""} id="sidebar">
            <div className="sidebar__title">
                <div className="sidebar__img">
                    <img src={logo} alt="logo" />
                    <h1>OnlineTest</h1>
                </div>
                <i className="fa fa-times" id="sidebarIcon" onClick={() => closeSidebar()}></i>
            </div>
            <div className="sidebar__menu">
                <div className="sidebar__link active_menu_link">
                    <i className="fa fa-home"></i>
                    <a className="active_link" href="#">Dashboard</a>
                    
                    <div className="sidebar__link">
                    <i class="bi bi-card-list"></i>
                        <a href="#">Subject</a>
                    </div>
                    <div className="sidebar__link">
                    <i class="bi bi-pen-fill"></i>
                        <a href="#">Exam</a>
                    </div>
                    <div className="sidebar__link">
                    <i class="bi bi-question-circle"></i>
                        <a href="#">Question</a>
                    </div>
                    <div className="sidebar__link">
                    <i class="bi bi-card-checklist"></i>
                        <a href="#">Student Performance</a>
                    </div>
                    <div className="sidebar__link">
                    <i class="bi bi-list-stars"></i>
                        <a href="#">Student List</a>
                    </div>

                </div>
            </div>
        </div>

    )
}

export default Sidebar;