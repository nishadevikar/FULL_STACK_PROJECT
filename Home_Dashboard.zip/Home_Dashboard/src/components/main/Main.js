import "./Main.css";
import hello from "../../assets/hello.png"
import Chart from "../charts/Chart";
const Main = () => {
    return(
        <main>
            <div className="main__container">
                <div className="main__title">
                         <img src={hello} alt="hello" />
                    <div className="main__greeting">
                            <h1>Hello Candidates</h1>
                        <p>Welcome to Online Exam</p>
                    </div>

                </div>

                    <div className="main__cards">
                    
                        <div className="card">
                                <i class="bi bi-card-list"></i>
                            <div className="card_inner">
                                <p className="text-primary-p">Number of User</p>
                                <span className="font-bold text-title">578</span>
                            </div>
                        </div>

                        <div className="card">
                        <i class="bi bi-card-list"></i>
                            <div className="card_inner">
                                <p className="text-primary-p">No. Of Candidates Appeared</p>
                                <span className="font-bold text-title">250</span>
                            </div>
                        </div>

                        <div className="card">
                        <i class="bi bi-card-list"></i>
                            <div className="card_inner">
                                <p className="text-primary-p">Number of Subjects</p>
                                <span className="font-bold text-title">5</span>
                            </div>
                        </div>

                        <div className="card">
                            <i class="bi bi-card-list"></i>
                            <div className="card_inner">
                                    <p className="text-primary-p">Number of Section</p>
                                    <span className="font-bold text-title">3</span>
                            </div>
                        </div>
                    </div>
                    <div className="charts">
                        <div className="charts__left">
                            <div className="charts__left__title">
                                <div>
                                     <h1>Performance Record</h1>
                                    <p>Subject, Section, Marks</p>
                                 </div>
                                <i class="fa-duotone fa-chart-line-up"></i>
                            </div>
                            <Chart />
                        </div>

                        <div className="charts__right">
                             <div className="charts__right__title">
                                <div>
                                    <h1>Assessment Evaluation</h1>
                                    <p>Subject, Section, Marks</p>
                                </div>
                                <i class="fa-duotone fa-chart-line-up"></i>
                             </div>
                
                             <div className="charts__right__cards">
                                <div className="card1">
                                    <h1>Passing_Percentile</h1>
                                     <p>100%</p>
                                </div>

                             <div className="card2">
                                <h1>Admin</h1>
                                 <p>5%</p>
                            </div>

                            <div className="card3">
                                <h1>Users</h1>
                                <p>100%</p>
                            </div>
                     </div>
                </div>
                
             </div>
            </div>
            </main>

    )
}


export default Main;