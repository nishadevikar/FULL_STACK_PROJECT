const Footer = () => {
    return (
      <div
        style={{
          textAlign: "center",
          marginBottom: 10,
        }}
      >
        Made by{"TEAM-1 "}
        <a
         
          style={{ cursor: "pointer" }}
        >
            <br></br>
         (NISHA PAYAL AJAY SHEFALI AJAY)
        </a>
      </div>
    );
  };
  
  export default Footer;